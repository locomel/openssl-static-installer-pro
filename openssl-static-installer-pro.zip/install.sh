#!/bin/bash
echo install
