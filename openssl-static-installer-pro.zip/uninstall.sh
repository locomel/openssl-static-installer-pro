#!/bin/bash
echo uninstall
