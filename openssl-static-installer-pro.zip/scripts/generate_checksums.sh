#!/bin/bash
echo sums
