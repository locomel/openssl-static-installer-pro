#!/bin/bash
echo env
