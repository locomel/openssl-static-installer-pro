#!/bin/bash
echo build
