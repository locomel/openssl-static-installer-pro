#!/bin/bash
echo verify
